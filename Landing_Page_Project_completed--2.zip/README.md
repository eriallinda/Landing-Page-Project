# Landing Page Project

## Description

This is a project that incorporates HTML, CSS and JavaScript to create a landing page. The landing page features a navigation bar with a menu containing four sections. When each section is clicked onto, it takes the user to the corresponding section within the web page. The user will observe that each item in the menu will highlight when a cursor is hovered over it,  when the section link is clicked, and/or while manually scrolling the page.  


## Instructions

Click on each section individually in the navigation menu to be taken to that corresponding section on the landing page.

Alternatively, user can manually scroll up and down the landing page to view each one of the four sections as well.
