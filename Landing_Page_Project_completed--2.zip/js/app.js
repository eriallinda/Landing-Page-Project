/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/



function buildNav() {

  const navBar = document.querySelector('.navbar__menu');         // This creates the navigation bar.
  const sections = document.querySelectorAll('section');        // This gathers the sections.
  sections.forEach((section, index) => {
    // This will iterate through the sections.
    const link = document.createElement('a');         // This is the anchor.
    link.textContent = `Section ${index + 1}`;        // This creates a label using the text content.
    link.href = `#${section.id}`;         // This is the link.
    const listItem = document.createElement('li');        // Creates the list item.
    listItem.appendChild(link);
    navBar.appendChild(listItem);         // This will append the list item to the navigation bar.
  });


  // This will add a click event listener to each anchor in the navigation bar.
  const navBarLinks = document.querySelectorAll('.navbar__menu a');

  navBarLinks.forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const targetElement = document.querySelector(link.getAttribute('href'));
      const yOffset = -65;
      const y =
        targetElement.getBoundingClientRect().top +
        window.pageYOffset +
        yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
      setActiveNav(link);         // Highlights the clicked section in the navigation bar.
    });
  });
}


// This creates a separate function in order to highlight the clicked link.
function setActiveNav(clickedLink) {

  const navBarLinks = document.querySelectorAll('.navbar__menu a');         //  This will collate the links from the navigation menu that have the anchor element.
  navBarLinks.forEach((link) => {
  link.classList.remove('active');
  });

  clickedLink.classList.add('active');         // Sets an argument as active in order to induce highlighting.
}


function setActive() {
  
  const navBar = document.querySelector('.navbar__menu');
  const sections = document.querySelectorAll('section');
  const activeSession = (entries) => {

    //  This creates an active session variable to add to the observer.

    entries.forEach((entry) => {
      const sectionId = entry.target.getAttribute('id');
      const link = navBar.querySelector(`[href="#${sectionId}"]`);

      if (entry.isIntersecting) {
        link.classList.add('active');         //  This adds an active class to the section if it is interesecting.
        entry.target.classList.add('your-active-class');
      } else {
        link.classList.remove('active');        // This removes an active class from section if it is intersecting
        entry.target.classList.remove('your-active-class');
      }
    });
  };


  const observer = new IntersectionObserver(activeSession, {        // This creates an observer for monitoring.

    
    root: null,
    rootMargin: '0px',
    threshold: 0.5,
  });

  sections.forEach((section) => observer.observe(section));
}


document.addEventListener('DOMContentLoaded', () => {
  buildNav();
  setActive();
});
